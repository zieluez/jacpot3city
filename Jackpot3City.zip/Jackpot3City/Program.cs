using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Minimal API + statyczne pliki (index.html itp.)
builder.Services.AddRouting();
var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();

// ====== "BAZA" UŻYTKOWNIKÓW W PAMIĘCI ======

var users = new List<User>
{
    new User
    {
        Login = "admin",
        Haslo = "admin123",
        Saldo = 0m
    },
    new User
    {
        Login = "gracz",
        Haslo = "gracz123",
        Saldo = 100m
    }
};

// ====== ENDPOINTY API ======

/// REJESTRACJA
app.MapPost("/api/register", (RegisterRequest req) =>
{
    if (string.IsNullOrWhiteSpace(req.Login) || string.IsNullOrWhiteSpace(req.Haslo))
    {
        return Results.Json(new
        {
            Sukces = false,
            Komunikat = "Login i hasło są wymagane."
        });
    }

    if (users.Any(u => u.Login.Equals(req.Login, StringComparison.OrdinalIgnoreCase)))
    {
        return Results.Json(new
        {
            Sukces = false,
            Komunikat = "Ten login jest już zajęty."
        });
    }

    if (!Validation.IsEmailValid(req.Email))
    {
        return Results.Json(new
        {
            Sukces = false,
            Komunikat = "Niepoprawny email."
        });
    }

    users.Add(new User
    {
        Login = req.Login,
        Haslo = req.Haslo,
        Email = req.Email,
        Saldo = 0m
    });

    return Results.Json(new
    {
        Sukces = true,
        Komunikat = "Konto utworzone. Możesz się zalogować."
    });
});

/// LOGOWANIE
app.MapPost("/api/login", (LoginRequest req) =>
{
    var user = users.FirstOrDefault(u =>
        u.Login.Equals(req.Login ?? "", StringComparison.OrdinalIgnoreCase) &&
        u.Haslo == (req.Haslo ?? "")
    );

    if (user == null)
    {
        return Results.Json(new
        {
            Sukces = false,
            Komunikat = "Błędny login lub hasło."
        });
    }

    return Results.Json(new
    {
        Sukces = true,
        Komunikat = $"Witaj, {user.Login}! Twoje saldo: {user.Saldo:0.00} zł.",
        Login = user.Login,
        Saldo = user.Saldo
    });
});

/// WPŁATA + WERYFIKACJA EMAIL / TELEFON / PESEL / IBAN
app.MapPost("/api/deposit", (DepositRequest req) =>
{
    // 1. znajdź użytkownika
    var user = users.FirstOrDefault(u =>
        u.Login.Equals(req.Login, StringComparison.OrdinalIgnoreCase));

    if (user == null)
    {
        return Results.Json(new
        {
            Sukces = false,
            Komunikat = "Nie znaleziono użytkownika o takim loginie."
        });
    }

    // 2. podstawowe sprawdzenia
    if (req.Kwota <= 0)
    {
        return Results.Json(new
        {
            Sukces = false,
            Komunikat = "Kwota wpłaty musi być większa od 0."
        });
    }

    // 3. WERYFIKACJA DANYCH
    var bledy = new List<string>();

    if (!Validation.IsEmailValid(req.Email))
        bledy.Add("Niepoprawny email.");

    if (!Validation.IsPhoneValid(req.Telefon))
        bledy.Add("Niepoprawny numer telefonu (wymagane 9 cyfr).");

    if (!Validation.IsPeselValid(req.Pesel))
        bledy.Add("Niepoprawny PESEL.");

    if (!Validation.IsIbanValid(req.Iban))
        bledy.Add("Niepoprawny IBAN (polski IBAN musi zaczynać się od PL i mieć 28 znaków).");

    if (bledy.Any())
    {
        return Results.Json(new
        {
            Sukces = false,
            Komunikat = string.Join(" ", bledy)
        });
    }

    // 4. jeśli wszystko OK – dopisujemy saldo + zapisujemy dane
    user.Saldo += req.Kwota;
    user.Email = req.Email;
    user.Telefon = req.Telefon;
    user.Pesel = req.Pesel;
    user.Iban = req.Iban;

    return Results.Json(new
    {
        Sukces = true,
        Komunikat = $"Wpłata {req.Kwota:0.00} zł przyjęta. Nowe saldo: {user.Saldo:0.00} zł.",
        NoweSaldo = user.Saldo
    });
});

// ====== GRY ======

/// BLACKJACK
app.MapGet("/api/blackjack/play", () =>
{
    var deck = CardUtils.CreateDeck();
    CardUtils.Shuffle(deck);

    var playerCards = new List<string> { deck[0], deck[2] };
    var dealerCards = new List<string> { deck[1], deck[3] };

    int playerPoints = CardUtils.BlackjackPoints(playerCards);
    int dealerPoints = CardUtils.BlackjackPoints(dealerCards);

    string msg;

    if (playerPoints > 21 && dealerPoints > 21)
        msg = "Oboje spaliliście się. Remis.";
    else if (playerPoints > 21)
        msg = "Przekroczyłeś 21 – przegrywasz.";
    else if (dealerPoints > 21)
        msg = "Krupier przekroczył 21 – wygrywasz!";
    else if (playerPoints > dealerPoints)
        msg = "Masz więcej punktów – wygrywasz!";
    else if (playerPoints < dealerPoints)
        msg = "Krupier ma więcej punktów – przegrywasz.";
    else
        msg = "Remis.";

    return Results.Json(new
    {
        KartyKrupiera = dealerCards,
        KartyGracza = playerCards,
        PunktyGracza = playerPoints,
        PunktyKrupiera = dealerPoints,
        Komunikat = msg
    });
});

/// POKER – uproszczony: porównujemy sumę wartości kart
app.MapGet("/api/poker/play", () =>
{
    var deck = CardUtils.CreateDeck();
    CardUtils.Shuffle(deck);

    var player = deck.Take(5).ToList();
    var dealer = deck.Skip(5).Take(5).ToList();

    int playerSum = CardUtils.SimpleValue(player);
    int dealerSum = CardUtils.SimpleValue(dealer);

    string msg;
    if (playerSum > dealerSum) msg = "Twoja ręka wygrywa.";
    else if (playerSum < dealerSum) msg = "Krupier ma lepszą rękę.";
    else msg = "Remis.";

    return Results.Json(new
    {
        KartyGracza = player,
        KartyKrupiera = dealer,
        SumaGracza = playerSum,
        SumaKrupiera = dealerSum,
        Komunikat = msg
    });
});

/// BAKARAT
app.MapGet("/api/bakarat/play", () =>
{
    var deck = CardUtils.CreateDeck();
    CardUtils.Shuffle(deck);

    var player = new List<string> { deck[0], deck[2] };
    var banker = new List<string> { deck[1], deck[3] };

    int playerPoints = CardUtils.BaccaratPoints(player);
    int bankerPoints = CardUtils.BaccaratPoints(banker);

    string winner;
    if (playerPoints > bankerPoints) winner = "Gracz";
    else if (playerPoints < bankerPoints) winner = "Bankier";
    else winner = "Remis";

    return Results.Json(new
    {
        KartyGracza = player,
        KartyBankiera = banker,
        PunktyGracza = playerPoints,
        PunktyBankiera = bankerPoints,
        Zwyciezca = winner
    });
});

/// SLOTS
app.MapGet("/api/slots/play", () =>
{
    string[] symbols = { "7️⃣", "⭐", "🍒", "💎", "🍋", "🔔" };
    var rnd = new Random();

    string[] reels = {
        symbols[rnd.Next(symbols.Length)],
        symbols[rnd.Next(symbols.Length)],
        symbols[rnd.Next(symbols.Length)]
    };

    string msg;
    if (reels[0] == reels[1] && reels[1] == reels[2])
        msg = "JACKPOT! Trzy takie same symbole!";
    else if (reels[0] == reels[1] || reels[1] == reels[2] || reels[0] == reels[2])
        msg = "Dwa takie same – mała wygrana!";
    else
        msg = "Nic nie weszło, spróbuj ponownie.";

    return Results.Json(new
    {
        Bebny = reels,
        Komunikat = msg
    });
});

/// BUKMACHERKA
app.MapGet("/api/bukmacherka/play", () =>
{
    var rnd = new Random();
    string[] mecze =
    {
        "Arka Gdynia – Lechia Gdańsk",
        "Real Madrid – Barcelona",
        "Legia Warszawa – Lech Poznań"
    };

    string typ = mecze[rnd.Next(mecze.Length)];
    double kurs = Math.Round(1.3 + rnd.NextDouble() * 3.0, 2);
    bool trafiony = rnd.Next(0, 2) == 1;

    string msg = trafiony ? "Kupon wszedł, gratulacje!" : "Kupon spalony.";

    return Results.Json(new
    {
        Typ = typ,
        Kurs = kurs,
        Trafiony = trafiony,
        Komunikat = msg
    });
});

app.Run();

// ====== KLASY POMOCNICZE ======

public class User
{
    public string Login { get; set; } = "";
    public string Haslo { get; set; } = "";
    public decimal Saldo { get; set; }

    public string? Email { get; set; }
    public string? Telefon { get; set; }
    public string? Pesel { get; set; }
    public string? Iban { get; set; }
}

public class RegisterRequest
{
    public string Login { get; set; } = "";
    public string Haslo { get; set; } = "";
    public string Email { get; set; } = "";
}

public class LoginRequest
{
    public string? Login { get; set; }
    public string? Haslo { get; set; }
}

public class DepositRequest
{
    public string Login { get; set; } = "";
    public string Email { get; set; } = "";
    public string Telefon { get; set; } = "";
    public string Pesel { get; set; } = "";
    public string Iban { get; set; } = "";
    public decimal Kwota { get; set; }
}

public static class Validation
{
    public static bool IsEmailValid(string? email)
    {
        if (string.IsNullOrWhiteSpace(email)) return false;
        if (!email.Contains("@")) return false;
        return email.Length >= 5;
    }

    public static bool IsPhoneValid(string? tel)
    {
        return !string.IsNullOrWhiteSpace(tel)
               && tel.Length == 9
               && tel.All(char.IsDigit);
    }

    public static bool IsPeselValid(string? pesel)
    {
        if (pesel == null || pesel.Length != 11 || !pesel.All(char.IsDigit))
            return false;

        int[] wagi = { 1, 3, 7, 9, 1, 3, 7, 9, 1, 3 };
        int suma = 0;

        for (int i = 0; i < 10; i++)
            suma += wagi[i] * (pesel[i] - '0');

        int kontrolna = (10 - (suma % 10)) % 10;
        return kontrolna == (pesel[10] - '0');
    }

    public static bool IsIbanValid(string? iban)
    {
        if (string.IsNullOrWhiteSpace(iban)) return false;
        iban = iban.Replace(" ", "").ToUpper();

        if (!iban.StartsWith("PL") || iban.Length != 28)
            return false;

        // algorytm mod-97
        string rearranged = iban[4..] + iban[..4];

        var sb = new StringBuilder();
        foreach (char c in rearranged)
        {
            if (char.IsDigit(c)) sb.Append(c);
            else sb.Append(((int)c - 55).ToString());
        }

        string num = sb.ToString();
        int rem = 0;
        foreach (char c in num)
        {
            rem = (rem * 10 + (c - '0')) % 97;
        }

        return rem == 1;
    }
}

public static class CardUtils
{
    private static readonly string[] Ranks =
        { "A", "K", "Q", "J", "10", "9", "8", "7", "6", "5", "4", "3", "2" };

    private static readonly string[] Suits =
        { "♠", "♥", "♦", "♣" };

    public static List<string> CreateDeck()
    {
        var deck = new List<string>();
        foreach (var r in Ranks)
        foreach (var s in Suits)
            deck.Add(r + s);
        return deck;
    }

    public static void Shuffle(List<string> deck)
    {
        var rnd = new Random();
        for (int i = deck.Count - 1; i > 0; i--)
        {
            int j = rnd.Next(i + 1);
            (deck[i], deck[j]) = (deck[j], deck[i]);
        }
    }

    public static int BlackjackPoints(IEnumerable<string> cards)
    {
        int sum = 0;
        int aces = 0;

        foreach (var c in cards)
        {
            string rank = c[..^1]; // bez koloru
            if (rank == "A")
            {
                aces++;
                sum += 11;
            }
            else if (rank is "K" or "Q" or "J" or "10")
            {
                sum += 10;
            }
            else
            {
                sum += int.Parse(rank);
            }
        }

        while (sum > 21 && aces > 0)
        {
            sum -= 10;
            aces--;
        }

        return sum;
    }

    // do uproszczonego "pokera"
    public static int SimpleValue(IEnumerable<string> cards)
    {
        int sum = 0;
        foreach (var c in cards)
        {
            string rank = c[..^1];
            sum += rank switch
            {
                "A" => 14,
                "K" => 13,
                "Q" => 12,
                "J" => 11,
                _ => int.Parse(rank)
            };
        }

        return sum;
    }

    // zasady bakarata (liczymy ostatnią cyfrę sumy)
    public static int BaccaratPoints(IEnumerable<string> cards)
    {
        int sum = 0;
        foreach (var c in cards)
        {
            string rank = c[..^1];
            int v = rank switch
            {
                "A" => 1,
                "K" or "Q" or "J" or "10" => 0,
                _ => int.Parse(rank)
            };
            sum += v;
        }

        return sum % 10;
    }
}
